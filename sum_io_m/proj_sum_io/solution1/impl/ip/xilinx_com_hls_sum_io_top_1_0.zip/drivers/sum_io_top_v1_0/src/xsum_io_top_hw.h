// ==============================================================
// File generated on Fri Jun 07 16:16:53 CEST 2019
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3.1 (64-bit)
// SW Build 2489853 on Tue Mar 26 04:18:30 MDT 2019
// IP Build 2486929 on Tue Mar 26 06:44:21 MDT 2019
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// AXILiteS
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of r_a
//        bit 31~0 - r_a[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of r_b
//        bit 31~0 - r_b[31:0] (Read/Write)
// 0x1c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSUM_IO_TOP_AXILITES_ADDR_R_A_DATA 0x10
#define XSUM_IO_TOP_AXILITES_BITS_R_A_DATA 32
#define XSUM_IO_TOP_AXILITES_ADDR_R_B_DATA 0x18
#define XSUM_IO_TOP_AXILITES_BITS_R_B_DATA 32

